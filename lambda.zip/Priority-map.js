export const Priority_map = {
    2: "1",//高 - Low
    3: "2",//中 - Medium
    4: "3",//低 - High
}